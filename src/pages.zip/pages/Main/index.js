import React from "react";

import { FaGithubAlt, FaPlus } from 'react-icons/fa'
import './index.css'

function Main(){
    return(
        <div className="Container">
            
            <h1>
            <FaGithubAlt/>
            Repositórios
            </h1>

            <form onSubmit={() => {}}>
                <input 
                type="text"
                placeholder="Adicionar repositório"
                ></input>

                <button type="submit" className="SubmitButton" disabled>
                    <FaPlus color="#fff" size={14}/>
                </button>
            </form>
        </div>
    )
}

export default Main